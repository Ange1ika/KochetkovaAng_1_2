﻿#include <stdio.h>
//#include "iostream"
//#include "stdarg.h"
//
// Kochetkova_1_2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
/*Считать с клавиатуры квадратную матрицу, состоящую из целых чисел.
Определить наибольший полный квадрат в каждой строке, столбце, и
диагонали.Вывести на экран.
* Полным квадратом называется число, являющееся квадратом некоторого
целого числа.*/
#include <ctime>
#include <malloc.h>
#include <new>
#include <locale>
#include <fstream>
#include <iostream>
constexpr auto MMax = -2147483648;

using namespace std;
void stroki(int** bb, int n);
void stolbci(int** bb, int n);
void maind(int** bb, int n);
void pobochd(int** bb, int n);
void printMatrix(int* matrix[], int n);
int main()
{
    int n, i, j, maxkvadrat;
    const int MMax = -1e30;
    //FILE* in = fopen("file.in", "rt");//файл чтения
    //FILE* out = fopen("file.out", "wt");//файл записи
    setlocale(LC_ALL, "Rus");
    maxkvadrat = MMax;
    ////Создаем файловый поток и связываем его с файлом
    //ifstream in;
    //in.open("input.txt",ios::in);
    //if (in.is_open())
    //    {
    //        //Если открытие файла прошло успешно

    //        //Вначале посчитаем сколько чисел в файле
    //        int count = 0;// число чисел в файле
    //        int temp;//Временная переменная

    //        while (!in.eof())// пробегаем пока не встретим конец файла eof
    //        {
    //            in >> temp;//в пустоту считываем из файла числа
    //            count++;// увеличиваем счетчик числа чисел
    //        }

    //        //Число чисел посчитано, теперь нам нужно понять сколько
    //        //чисел в одной строке
    //        //Для этого посчитаем число пробелов до знака перевода на новую строку

    //        //Вначале переведем каретку в потоке в начало файла
    //        in.seekg(0, ios::beg);
    //        in.clear();

    //        //Число пробелов в первой строчке вначале равно 0
    //        int count_space = 0;
    //        char symbol;
    //        while (!in.eof())//на всякий случай цикл ограничиваем концом файла
    //        {
    //            //теперь нам нужно считывать не числа, а посимвольно считывать данные
    //            in.get(symbol);//считали текущий символ
    //            if (symbol == ' ') count_space++;//Если это пробел, то число пробелов увеличиваем
    //            if (symbol == '\n') break;//Если дошли до конца строки, то выходим из цикла
    //        }
    //        //cout << count_space << endl;

    //        //Опять переходим в потоке в начало файла
    //        in.seekg(0, ios::beg);
    //        in.clear();

    //        //Теперь мы знаем сколько чисел в файле и сколько пробелов в первой строке.
    //        //Теперь можем считать матрицу.

    //        int n = count / (count_space + 1);//число строк
    //        int m = count_space + 1;//число столбцов на единицу больше числа пробелов
    //        int** bb = new int* [m];
    //        for (i = 0; i < m; i++) {
    //            bb[i] = new int[m];//цикл выделения динамической памяти под массив
    //            int** aa = new int* [m];
    //            for (i = 0; i < m; i++) {
    //                aa[i] = new int[m];//цикл выделения динамической памяти под массив
    //            }

    //            //Считаем матрицу из файла
    //            for (int i = 0; i < n; i++) {
    //                for (int j = 0; j < m; j++) {
    //                    in >> bb[i][j];
    //                    bb[i][j] = aa[i][j] * aa[i][j];//заполнение матрицы квадратов
    //                }
    //            }
    //            stroki(bb, n);
    //            stolbci(bb, n);
    //            maind(bb, n);
    //            pobochd(bb, n);
    //            for (i = 0; i < n; i++) {
    //                delete[] aa[i];
    //                delete[] bb[i];
    //                cin.get();
    //                return 0;
    //            }

    //            //Выведем матрицу
    //            /*for (int i = 0; i < n; i++)
    //            {
    //                for (int j = 0; j < m; j++)
    //                    cout << x[i][j] << "\t";
    //                cout << "\n";
    //            }*/


    //            in.close();//под конец закроем файл
    //        }
    //    }
    //    else
    //    {
    //        //Если открытие файла прошло не успешно
    //        cout << "Файл не найден.";
    //    }

    //    system("pause");
        ifstream in("input.txt");
        if (in.is_open())
        {

            cout << "Введите количество строк и столбцов квадратной матрицы (целое число, соответствующее для всех параметров)\n";
            scanf("%d", &n); //Считали n
            int** aa = new int* [n];
            for (i = 0; i < n; i++) {
                aa[i] = new int[n];//цикл выделения динамической памяти под массив
            }
            int** bb = new int* [n];
            for (i = 0; i < n; i++) {
                bb[i] = new int[n];//цикл выделения динамической памяти под массив
            }
            //cout << "\nВведите элементы массива(целые числа)\n";
            maxkvadrat = MMax;
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < n; j++)
                {
                    in>>aa[i][j];//ввод элементов матрицы
                    bb[i][j] = aa[i][j] * aa[i][j];//заполнение матрицы квадратов
                }
            }
            printMatrix(aa, n);
        }
    }

void stroki(int** bb, int n)//поиск и вывод максимального полного квадрата в строках
{
    int i, j, maxkvadrat;
    maxkvadrat = MMax;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++)
        {
            if (bb[i][j] > maxkvadrat)
            {
                maxkvadrat = bb[i][j];// поиск максимального полного квадрата в строке
            }
        }
       
        cout << "\nMax полный квадрат" << i + 1 << "строки =" << maxkvadrat;

    }

}
void stolbci(int** bb, int n)//поиск и вывод максимального полного квадрата в столбцах
{
    int i, j, maxkvadrat;
    maxkvadrat = MMax;
    for (j = 0; j < n; j++) {
        for (i = 0; i < n; i++)
        {
            if (bb[i][j] > maxkvadrat)
            {
                maxkvadrat = bb[i][j];// поиск максимального полного квадрата в столбце
            }
        }cout << "\nMax полный квадрат" << j + 1 << "столбца =" << maxkvadrat;

    }

}
void maind(int** bb, int n)//поиск и вывод максимального полного квадрата на главной диагонали
{
    int i, j, maxkvadrat;
    maxkvadrat = MMax;
    for (i = 0; i < n; i++) {
        if (bb[i][i] > maxkvadrat)
        {
            maxkvadrat = bb[i][i];// поиск максимального полного квадрата в главной диагонали
        }
    }
    cout << "\nMax полный квадрат главной диагонали =" << maxkvadrat;

}
void pobochd(int** bb, int n)//поиск и вывод максимального полного квадрата на побочной диагонали
{
    int i, j, maxkvadrat;
    maxkvadrat = MMax;
    for (i = 0; i < n; i++) {
        if (bb[i][n - i - 1] > maxkvadrat)
        {
            maxkvadrat = bb[i][n - i - 1];// поиск максимального полного квадрата в побочной диагонали
        }
    }
    cout << "\nMax полный квадрат побочной диагонали =" << maxkvadrat;
}

void printMatrix(int* matrix[], int n)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}